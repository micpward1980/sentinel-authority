#!/usr/bin/env python3
"""
Patches agent.py to integrate the auto-discovery engine.
Run from: ~/Downloads/sentinel-authority/website/downloads/envelo-docker/
"""

import re

AGENT_PATH = "envelo/agent.py"

with open(AGENT_PATH) as f:
    code = f.read()

# ---- 1. Add discovery import at top, after existing imports ----
old_import = "from .exceptions import ("
new_import = """from .discovery import DiscoveryEngine
from .exceptions import ("""
code = code.replace(old_import, new_import, 1)

# ---- 2. Add discovery engine to __init__ ----
# Find the end of __init__ assignments and add discovery engine setup
old_init_end = """        self._lock = threading.Lock()"""
new_init_end = """        self._lock = threading.Lock()

        # Auto-discovery engine
        self._discovery = DiscoveryEngine(
            min_samples=kwargs.get("discovery_samples", 200),
            discovery_duration=kwargs.get("discovery_duration", 300.0),
            safety_margin=kwargs.get("safety_margin", 0.10),
            geo_buffer_meters=kwargs.get("geo_buffer_meters", 50.0),
            auto_transition=True,
            on_boundaries_ready=self._on_discovery_complete,
        )
        self._discovery_mode = False"""
code = code.replace(old_init_end, new_init_end, 1)

# ---- 3. Patch start() to enter discovery mode when no boundaries from server ----
old_fetch_check = """        if not self._fetch_boundaries():"""
new_fetch_check = """        if not self._fetch_boundaries():
            # No server boundaries — enter auto-discovery mode
            self.logger.info("[ENVELO] No boundaries from server — entering auto-discovery mode")
            self._discovery_mode = True
            self._discovery.start()"""
code = code.replace(old_fetch_check, new_fetch_check, 1)

# ---- 4. Patch check() to feed discovery engine and handle discovery mode ----
old_check_start = '''    def check(self, **params) -> bool:'''
new_check_start = '''    def check(self, **params) -> bool:
        # Feed parameters to discovery engine if in discovery mode
        if self._discovery_mode:
            self._discovery.observe(**params)
            if self._discovery.state == DiscoveryEngine.ENFORCING:
                # Discovery complete — boundaries are now loaded
                self._discovery_mode = False
                self.logger.info("[ENVELO] Discovery complete — enforcement active")
            else:
                # Still discovering — allow all actions
                self._queue_telemetry("check", params, "ALLOW_DISCOVERY")
                return True
'''
code = code.replace(old_check_start, new_check_start, 1)

# ---- 5. Add discovery completion callback method ----
old_is_running = """    def is_running(self) -> bool:"""
new_is_running = """    def _on_discovery_complete(self, boundaries, envelope_definition):
        \"\"\"Called when auto-discovery finishes generating boundaries.\"\"\"
        self.logger.info(f"[ENVELO] Auto-discovered {len(boundaries)} boundaries")

        # Load discovered boundaries into enforcement engine
        for b in boundaries:
            self._boundaries[b.parameter] = b
            self.logger.info(f"  → {b.name}: {b.parameter}")

        # Upload envelope to Sentinel Authority
        try:
            resp = requests.post(
                f"{self.config.api_endpoint}/api/envelo/boundaries/discovered",
                headers={"Authorization": f"Bearer {self.config.api_key}"},
                json={
                    "session_id": self._session_id,
                    "envelope_definition": envelope_definition,
                },
                timeout=10,
            )
            if resp.ok:
                self.logger.info("[ENVELO] Envelope uploaded to Sentinel Authority")
            else:
                self.logger.warning(f"[ENVELO] Envelope upload failed: {resp.status_code}")
        except Exception as e:
            self.logger.warning(f"[ENVELO] Envelope upload error: {e}")
            # Still enforce locally even if upload fails

        self.logger.info("[ENVELO] ═══════════════════════════════════════════")
        self.logger.info("[ENVELO] AUTO-DISCOVERY COMPLETE — ENFORCEMENT ACTIVE")
        self.logger.info(f"[ENVELO] {len(boundaries)} boundaries now enforced")
        self.logger.info("[ENVELO] ═══════════════════════════════════════════")

    def get_discovery_stats(self):
        \"\"\"Return current auto-discovery statistics.\"\"\"
        return self._discovery.get_discovery_stats()

    def is_running(self) -> bool:"""
code = code.replace(old_is_running, new_is_running, 1)

# ---- 6. Patch enforce decorator to also feed discovery ----
old_wrapper = """            def wrapper(*args, **kwargs):"""
new_wrapper = """            def wrapper(*args, **kwargs):
                # Feed discovery engine
                if self._discovery_mode:
                    mapped = {}
                    sig_params = list(fn.__code__.co_varnames[:fn.__code__.co_argcount])
                    for i, arg in enumerate(args):
                        if i < len(sig_params):
                            mapped[sig_params[i]] = arg
                    mapped.update(kwargs)
                    self._discovery.observe(**mapped)
                    if self._discovery.state == DiscoveryEngine.ENFORCING:
                        self._discovery_mode = False
                    else:
                        return fn(*args, **kwargs)  # Allow during discovery"""
code = code.replace(old_wrapper, new_wrapper, 1)

# Write patched file
with open(AGENT_PATH, "w") as f:
    f.write(code)

print(f"✅ agent.py patched — {len(code)} chars")
print("   - Discovery import added")
print("   - Discovery engine initialized in __init__")
print("   - start() enters discovery when no server boundaries")
print("   - check() feeds discovery engine, allows all during discovery")
print("   - enforce() feeds discovery engine during discovery")
print("   - _on_discovery_complete() loads boundaries + uploads envelope")
print("   - get_discovery_stats() exposed")
